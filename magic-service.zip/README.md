<h4>Cambios:</h4>  
<ul>   
    <li>Creada la función que hace que el porcentaje vaya de 0.1 hasta 1.0 de 10 en 10</li>
    <li>Creada la función que valida que en porcentaje no se peuda escribir una cantidad superior a 1</li>

</ul>

<h4>Correcciones:</h4> 
<ul>
    <li></li>
</ul>

