<?php
    echo view('includes/header')
        //.view('includes/botonera')
        .view($main_content);