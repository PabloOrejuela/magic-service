<?php
    echo view('includes/header_login')
        //.view('includes/botonera')
        .view($main_content);